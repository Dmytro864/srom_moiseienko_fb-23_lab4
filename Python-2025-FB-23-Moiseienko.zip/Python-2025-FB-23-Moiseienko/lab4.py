import time
import random

class GF2mNB:
    def __init__(self, bits: list, m=113):
        self.m = m
        if len(bits) != m:
            raise ValueError(f"Елемент має бути {m}-бітним")
        self.bits = bits[:]

    def __str__(self):
        return ''.join(str(b) for b in self.bits)

    @staticmethod
    def zero(m=113):
        return GF2mNB([0] * m, m)

    @staticmethod
    def one(m=113):
        return GF2mNB([1] * m, m)

    @staticmethod
    def random(m=113):
        return GF2mNB([random.randint(0, 1) for _ in range(m)], m)

    def add(self, other):
        return GF2mNB([a ^ b for a, b in zip(self.bits, other.bits)], self.m)

    def square(self):
        return GF2mNB([self.bits[(i - 1) % self.m] for i in range(self.m)], self.m)  # циклічний зсув вправо

    def trace(self):
        return sum(self.bits) % 2

    def to_bin_str(self):
        return ''.join(str(b) for b in self.bits)

    @staticmethod
    def from_bin_str(bin_str):
        return GF2mNB([int(b) for b in bin_str], len(bin_str))

    def pow(self, exponent):
        result = GF2mNB.one(self.m)
        base = GF2mNB(self.bits, self.m)
        while exponent > 0:
            if exponent & 1:
                result = result.mul(base)
            base = base.square()
            exponent >>= 1
        return result

    def inverse(self):
        return self.pow((1 << self.m) - 2)

    def shift_left(self, vec, shift):
        return [vec[(i + shift) % self.m] for i in range(self.m)]

    def mul(self, other):
        # Побудова матриці Λ (в онб)
        p = 2 * self.m + 1
        Lambda = [[0] * self.m for _ in range(self.m)]
        for i in range(self.m):
            for j in range(self.m):
                if any((i - j) % p == v for v in [1, -1, p - 1, p + 1]):
                    Lambda[i][j] = 1

        result = [0] * self.m
        for i in range(self.m):
            u_shift = self.shift_left(self.bits, i)
            v_shift = self.shift_left(other.bits, i)
            temp = 0
            for r in range(self.m):
                for s in range(self.m):
                    temp ^= u_shift[r] & Lambda[r][s] & v_shift[s]
            result[i] = temp
        return GF2mNB(result, self.m)

# ==== Тести ====
def test_op(name, func):
    start = time.perf_counter()
    result = func()
    end = time.perf_counter()
    print(f"{name}: {result} (Час: {round((end - start) * 1e6)} мкс)")

a = GF2mNB.from_bin_str('0'*112 + '1')     # a = 1
b = GF2mNB.from_bin_str('0'*111 + '10')    # b = 2
c = GF2mNB.from_bin_str('0'*110 + '101')   # c = 5
d = GF2mNB.from_bin_str('0'*110 + '111')   # d = 7

print("Елементи:")
print("a =", a)
print("b =", b)
print("c =", c)
print("d =", d)

test_op("a + b", lambda: a.add(b))
test_op("a * b", lambda: a.mul(b))
test_op("a^2", lambda: a.square())
test_op("b^27", lambda: b.pow(27))
test_op("inverse(c)", lambda: c.inverse())
test_op("trace(d)", lambda: d.trace())

# Перевірка тотожностей
left = a.add(b).mul(c)
right = b.mul(c).add(c.mul(a))
print("\nТотожність (a + b) * c == b * c + c * a:", left.bits == right.bits)

d_inv = d.inverse()
d_check = d.mul(d_inv)
print("d * d^-1 = ", d_check)
print("Перевірка d * d^-1 == 1:", d_check.to_bin_str() == GF2mNB.one().to_bin_str())
