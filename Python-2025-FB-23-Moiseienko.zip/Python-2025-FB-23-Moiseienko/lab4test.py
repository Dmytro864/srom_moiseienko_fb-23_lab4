# ==== Тести ====
def test_op(name, func):
    start = time.perf_counter()
    result = func()
    end = time.perf_counter()
    print(f"{name}: {result} (Час: {round((end - start) * 1e6)} мкс)")

a = GF2mNB.from_bin_str('0'*112 + '1')     # a = 1
b = GF2mNB.from_bin_str('0'*111 + '10')    # b = 2
c = GF2mNB.from_bin_str('0'*110 + '101')   # c = 5
d = GF2mNB.from_bin_str('0'*110 + '111')   # d = 7

print("Елементи:")
print("a =", a)
print("b =", b)
print("c =", c)
print("d =", d)

test_op("a + b", lambda: a.add(b))
test_op("a * b", lambda: a.mul(b))
test_op("a^2", lambda: a.square())
test_op("b^27", lambda: b.pow(27))
test_op("inverse(c)", lambda: c.inverse())
test_op("trace(d)", lambda: d.trace())